let form = document.querySelecter('form');
form.addEventListener('submit', (e) => {
  e.preventDefault();
  return false;
});